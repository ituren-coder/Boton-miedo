EL BOTÓN DEL MIEDO — guía rápida

ARCHIVOS
- index.html: estructura de la app
- styles.css: diseño cálido y pastel
- app.js: llamadas y funcionalidades
- manifest.webmanifest: metadatos de instalación

CONFIGURAR EL TELÉFONO
1. Publica la carpeta en GitHub Pages (o cualquier hosting HTTPS).
2. Abre la dirección publicada en Safari desde el iPhone de Candela.
3. Toca "Ajustes", introduce tu número y guarda.
4. Prueba "Quiero llamarle". iOS abrirá Teléfono y puede pedir confirmar.

INSTALAR EN IPHONE
1. En Safari, abre la web publicada.
2. Pulsa Compartir.
3. Selecciona "Añadir a pantalla de inicio".
4. Confirma "Añadir".

NOTAS
- El número se guarda únicamente en el almacenamiento local de ese navegador/dispositivo.
- La web no puede iniciar una llamada silenciosa: iOS controla la confirmación.
- Para que funcione como app instalada y se pueda usar desde la pantalla de inicio, debe estar publicada con HTTPS.
- El prototipo usa una fuente externa opcional; si no hay conexión, se mostrará una fuente alternativa.
- Es una herramienta de apoyo, no un servicio de emergencias.
