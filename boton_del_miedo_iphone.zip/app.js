const $ = (id) => document.getElementById(id);
const dialog = $("settingsDialog");
const phoneInput = $("phoneInput");
const nameInput = $("nameInput");
const callButton = $("callButton");

function loadSettings(){
  phoneInput.value = localStorage.getItem("trustedPhone") || "";
  nameInput.value = localStorage.getItem("trustedName") || "Mi persona de confianza";
}
loadSettings();

callButton.addEventListener("click", () => {
  const phone = localStorage.getItem("trustedPhone") || "";
  if (!phone.trim()) {
    loadSettings();
    dialog.showModal();
    return;
  }
  window.location.href = `tel:${phone.replace(/[^\d+]/g, "")}`;
});

$("settingsButton").addEventListener("click", () => {
  loadSettings();
  dialog.showModal();
});

$("settingsForm").addEventListener("submit", (event) => {
  if (event.submitter?.value === "save") {
    event.preventDefault();
    localStorage.setItem("trustedPhone", phoneInput.value.trim());
    localStorage.setItem("trustedName", nameInput.value.trim() || "Mi persona de confianza");
    dialog.close();
  }
});

document.querySelectorAll("[data-panel]").forEach(button => {
  button.addEventListener("click", () => showPanel(button.dataset.panel));
});
document.querySelectorAll(".back").forEach(button => button.addEventListener("click", showHome));

function showPanel(id){
  $("question").closest(".main-card").classList.add("hidden");
  document.querySelectorAll(".panel").forEach(panel => panel.classList.add("hidden"));
  $(id).classList.remove("hidden");
}
function showHome(){
  document.querySelectorAll(".panel").forEach(panel => panel.classList.add("hidden"));
  document.querySelector(".main-card").classList.remove("hidden");
}

const quotes = [
  "No necesitas sentirte perfectamente bien para poder seguir con tu día.",
  "Una sensación desagradable no es una emergencia. Puedes ir paso a paso.",
  "No tienes que luchar contra cada pensamiento. Puedes dejarlo pasar y volver a lo que estabas haciendo.",
  "Ya has atravesado momentos difíciles antes. Este momento también cambiará.",
  "Sé amable contigo. Estás haciendo lo que puedes, y eso es suficiente."
];
let quoteIndex = 0;
$("nextQuote").addEventListener("click", () => {
  quoteIndex = (quoteIndex + 1) % quotes.length;
  $("quoteText").textContent = quotes[quoteIndex];
});

const activities = [
  "Busca cinco cosas de tu alrededor que tengan un color bonito.",
  "Pon una canción que te recuerde a un momento feliz.",
  "Mira por la ventana y describe mentalmente lo que está pasando fuera.",
  "Estira suavemente los hombros y las manos.",
  "Piensa en algo pequeño que te apetezca hacer cuando termine este rato.",
  "Bebe un poco de agua si te apetece y cambia de postura."
];
let activityIndex = 0;
$("nextActivity").addEventListener("click", () => {
  activityIndex = (activityIndex + 1) % activities.length;
  $("activityText").textContent = activities[activityIndex];
});

let breathInterval = null;
let breathTimeout = null;
let running = false;
function stopBreathing(){
  clearInterval(breathInterval);
  clearTimeout(breathTimeout);
  running = false;
  $("breathCircle").classList.remove("expand");
  $("breathWord").textContent = "Pulsa empezar";
  $("breathStart").textContent = "Empezar";
  $("breathTimer").textContent = "3 minutos · suave y sin forzar";
}
$("breathStart").addEventListener("click", () => {
  if (running) { stopBreathing(); return; }
  running = true;
  let remaining = 180;
  let phase = 0;
  const phases = [
    {word:"Inspira", duration:4000, expand:true},
    {word:"Espira", duration:6000, expand:false}
  ];
  function runPhase(){
    if (!running) return;
    const current = phases[phase % 2];
    $("breathWord").textContent = current.word;
    $("breathCircle").classList.toggle("expand", current.expand);
    phase++;
    breathTimeout = setTimeout(runPhase, current.duration);
  }
  runPhase();
  $("breathStart").textContent = "Terminar";
  $("breathTimer").textContent = "Sigue el ritmo sin forzar";
  breathInterval = setInterval(() => {
    remaining--;
    if (remaining <= 0) {
      stopBreathing();
      $("breathWord").textContent = "Muy bien ♡";
      $("breathTimer").textContent = "Has dedicado un momento a cuidarte.";
    }
  }, 1000);
});
document.querySelectorAll(".back").forEach(button => button.addEventListener("click", stopBreathing));
